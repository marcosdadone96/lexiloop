/* Per-chunk exam prompts � authentic content, anti-placeholder, Netlify 26�60s per chunk */
const ExamModulePrompts = (() => {
  const JR =
    'Return ONE JSON object (not an array). Escape double quotes in strings. No markdown. Start with { end with }.';

  const GLOBAL_DE =
    'Devuelve SOLO JSON valido. TODO el contenido debe ser AUTENTICO y COMPLETO. CERO placeholders ("...", "Option A", "Text here", "Ein Text ueber", etc.). Textos con la longitud REAL indicada. Preguntas verificables en el texto.';

  const GLOBAL_EN =
    'Return ONLY valid JSON. ALL content must be AUTHENTIC and COMPLETE. ZERO placeholders ("...", "Option A", "Text here", "An article about", etc.). Texts must match the REAL word count. Questions answerable ONLY from the generated text.';

  const ANTI_DE =
    'CRITICO: Genera contenido REAL y AUTENTICO. NINGUN placeholder. Los textos deben tener exactamente la longitud indicada. Las preguntas deben ser verificables en los textos generados.';

  const ANTI_EN =
    'CRITICAL: Generate REAL, COMPLETE, AUTHENTIC content. NO placeholders whatsoever. All texts must be FULLY WRITTEN with the specified word count. All questions answerable ONLY from the generated text. Correct answers clearly supported by the text.';

  function badGoodDE(topic) {
    return (
      `MALO: {"text":"Ein Text ueber ${topic}."} ` +
      `BIEN: {"text":"Maria arbeitet seit drei Jahren als Krankenschwester in Berlin. Sie faehrt jeden Morgen mit der U-Bahn..."}`
    );
  }

  function badGoodEN(topic) {
    return (
      `BAD: {"text":"An article about ${topic}."} ` +
      `GOOD: {"text":"Every summer, thousands of tourists visit the coastal town of Whitby to explore its historic abbey..."}`
    );
  }

  function goetheBase(level, topic, key, detail, extra) {
    return (
      `${ANTI_DE}\nGoethe-Institut ${level} exam writer. Topic: "${topic}". Language: German. ` +
      `Root keys: topic, level:"${level}", lang:"de", ${key}. ${detail}\n${badGoodDE(topic)}\n${GLOBAL_DE}\n${JR}${extra || ''}`
    );
  }

  function camBase(level, cert, topic, key, detail, extra) {
    return (
      `${ANTI_EN}\nCambridge ${level} (${cert}) exam writer. Topic: "${topic}". Language: English. ` +
      `Root keys: topic, level:"${level}", lang:"en", ${key}. ${detail}\n${badGoodEN(topic)}\n${GLOBAL_EN}\n${JR}` +
      ` official:{board:"Cambridge Assessment English",certificate:"${cert}"}. modules for reading/listening/writing/speaking.${extra || ''}`
    );
  }

  function g(key, detail, maxTokens, label, prompt) {
    return { expectKey: key, maxTokens, label, prompt };
  }

  function goetheA1(topic) {
    return [
      g(
        'lesenParts',
        'A1 reading chunk 1',
        2000,
        '1/4: Lesen',
        goetheBase(
          'A1',
          topic,
          'lesenParts',
          'Teil 1: Five short signs/notices/messages (15-25 words each, A1, topic). Each: question "Was bedeutet das?" with options a/b/c and correct answer. ' +
            'Teil 2: One continuous A1 text (70-90 words, topic) + 5 Richtig/Falsch questions verifiable in text. goetheFormat:true, official.certificate:"Start Deutsch 1", modules.lesen.',
        ),
      ),
      g(
        'horenParts',
        'A1 listening',
        2000,
        '2/4: Hoeren',
        goetheBase(
          'A1',
          topic,
          'horenParts',
          'horenParts must be an ARRAY with exactly 2 objects. ' +
            'Item 1 (teil:1): instruction, plays:2, segments: array of 5 objects each with label ("Aufnahme 1"�), transcript (30-50 words A1 German, topic), questions: [{id,type:"multiple",question,options:["a)...","b)...","c)..."],correct:"a"}]. ' +
            'Item 2 (teil:2): instruction, plays:2, transcript: dialogue 60-80 words A1, questions: 5 objects type:"richtig_falsch", correct:"Richtig" or "Falsch". ' +
            'Structure: { "horenParts": [{ "teil":1, "segments":[...] }, { "teil":2, "transcript":"A: ... B: ...", "questions":[...] }] }',
        ),
      ),
      g(
        'schreibenParts',
        'A1 writing',
        1200,
        '3/4: Schreiben',
        goetheBase(
          'A1',
          topic,
          'schreibenParts',
          'Aufgabe 1: Form to fill (name, date, nationality, email) with clear A1 instructions. ' +
            'Aufgabe 2: Writing task 25-35 words, concrete situation about topic. Include modelAnswer and criteria for each.',
        ),
      ),
      g(
        'sprechenParts',
        'A1 speaking',
        1000,
        '4/4: Sprechen',
        goetheBase(
          'A1',
          topic,
          'sprechenParts',
          'Teil 1: 5 personal introduction questions (Name, Herkunft, Wohnort, Beruf, Sprachen). ' +
            'Teil 2: Communication card A1 about topic with 3 points to discuss. Include situation, points, modelAnswer.',
        ),
      ),
    ];
  }

  function goetheA2(topic) {
    return [
      g(
        'lesenParts',
        'A2 reading 1-2',
        2400,
        '1/5: Lesen 1-2',
        goetheBase(
          'A2',
          topic,
          'lesenParts',
          'Teil 1: Five notices/signs (20-35 words A2) + 5 multiple choice a/b/c. ' +
            'Teil 2: A2 text (100-130 words, topic) + 5 Richtig/Falsch. goetheFormat:true, official.certificate:"Goethe-Zertifikat A2", modules.lesen.',
        ),
      ),
      g(
        'lesenParts',
        'A2 reading 3-4',
        2000,
        '2/5: Lesen 3-4',
        goetheBase(
          'A2',
          topic,
          'lesenParts',
          'Teil 3: Three short texts same theme (50-70 words each) + 5 matching questions (which text matches each statement). ' +
            'Teil 4: Notice/board text (80-100 words A2) + 5 multiple choice. lesenParts array with 2 items.',
        ),
      ),
      g(
        'horenParts',
        'A2 listening',
        2400,
        '3/5: Hoeren',
        goetheBase(
          'A2',
          topic,
          'horenParts',
          'horenParts must be an ARRAY with exactly 2 objects. ' +
            'Item 1 (teil:1): instruction, plays:2, segments: array of 5 objects each with label, transcript (40-60 words A2 dialogue), questions: [{id,type:"multiple",question,options:["a)...","b)...","c)..."],correct}]. ' +
            'Item 2 (teil:2): instruction, plays:2, transcript: voicemail 70-90 words A2, questions: 5 type:"richtig_falsch", correct:"Richtig"/"Falsch". ' +
            'Structure: { "horenParts": [{ "teil":1, "segments":[...] }, { "teil":2, "transcript":"...", "questions":[...] }] }',
        ),
      ),
      g(
        'schreibenParts',
        'A2 writing',
        1500,
        '4/5: Schreiben',
        goetheBase(
          'A2',
          topic,
          'schreibenParts',
          'Aufgabe 1: Informal email A2 (40-50 words). Situation: reply to invitation about topic. Three mandatory content points. modelAnswer included.',
        ),
      ),
      g(
        'sprechenParts',
        'A2 speaking',
        1200,
        '5/5: Sprechen',
        goetheBase(
          'A2',
          topic,
          'sprechenParts',
          'Teil 1: 5 questions about daily routine and life (A2, topic). ' +
            'Teil 2: Joint planning situation. Card with 3 elements to negotiate. modelAnswer.',
        ),
      ),
    ];
  }

  function goetheB1(topic) {
    const b = (key, detail, maxTokens, label) =>
      g(key, detail, maxTokens, label, goetheBase('B1', topic, key, detail, ' official.certificate:"Goethe-Zertifikat B1".'));
    return [
      b(
        'lesenParts',
        'Teil 1: Blog post 180 words + 6 R/F. Teil 2: Press article 220 words + 6 multiple choice. goetheFormat:true, modules.lesen.',
        3200,
        '1/10: Lesen 1-2',
      ),
      b('lesenParts', 'ONLY Teil 3: 6 ads A-F (full text each) + 5 person-situation matching questions. Array length 1.', 2400, '2/10: Lesen 3'),
      b('lesenParts', 'ONLY Teil 4: Five reader opinions (40-60 words each) + 5 Ja/Nein questions. Array length 1.', 2200, '3/10: Lesen 4'),
      b('lesenParts', 'ONLY Teil 5: Rules/regulations text 130 words + 5 multiple choice. Array length 1.', 2200, '4/10: Lesen 5'),
      b(
        'horenParts',
        'ONLY Hoeren Teil 1. horenParts must be an ARRAY with exactly 1 object. That object: teil:1, instruction:"Hoeren Sie...", plays:2, segments: array of 2 objects each with label ("Nachricht 1"/"Nachricht 2"), transcript (60-80 words German voicemail), questions: [{id,type:"multiple",question,options:["A)...","B)...","C)..."],correct:"A"}]. Structure: { "horenParts": [{ "teil":1, "plays":2, "segments":[...] }] }',
        2600,
        '5/10: Hoeren 1',
      ),
      b(
        'horenParts',
        'ONLY Hoeren Teil 2. horenParts must be an ARRAY with exactly 1 object. That object: teil:2, instruction, plays:2, transcript: dialogue 160-200 words "A: ... B: ...", questions: 5-6 mix of type:"richtig_falsch" (correct:"Richtig"/"Falsch") and type:"multiple" (options A/B/C). Structure: { "horenParts": [{ "teil":2, "transcript":"...", "questions":[...] }] }',
        2600,
        '6/10: Hoeren 2',
      ),
      b(
        'horenParts',
        'ONLY Hoeren Teil 3. horenParts must be an ARRAY with exactly 1 object. That object: teil:3, instruction:"Hoeren Sie ein Interview.", plays:2, context: brief situation, transcript: interview 180-220 words "Interviewer: ... Gast: ...", questions: 5 type:"multiple" with options A/B/C. Structure: { "horenParts": [{ "teil":3, "transcript":"...", "questions":[...] }] }',
        2600,
        '7/10: Hoeren 3',
      ),
      b(
        'horenParts',
        'ONLY Hoeren Teil 4. horenParts must be an ARRAY with exactly 1 object. That object: teil:4, instruction:"Hoeren Sie und ergaenzen Sie.", plays:2, transcript: monologue 180-220 words with facts/numbers, notesTitle:"Notizen", noteFields: 5 objects {id:"note1"�"note5", label: incomplete sentence German, answer: 1-3 words verifiable in transcript}. Structure: { "horenParts": [{ "teil":4, "transcript":"...", "notesTitle":"Notizen", "noteFields":[...] }] }',
        2600,
        '8/10: Hoeren 4',
      ),
      b('schreibenParts', 'Teil 1 forum post 80 words + Teil 2 formal email 120 words. Two items in array with task, criteria, modelAnswer.', 2200, '9/10: Schreiben'),
      b('sprechenParts', 'Teil 1 planning dialogue + Teil 2 presentation with 3 examiner questions. Two items with situation, points, modelAnswer.', 2000, '10/10: Sprechen'),
    ];
  }

  function goetheB2(topic) {
    const b = (key, detail, maxTokens, label) =>
      g(key, detail, maxTokens, label, goetheBase('B2', topic, key, detail, ' official.certificate:"Goethe-Zertifikat B2".'));
    return [
      b(
        'lesenParts',
        'Teil 1: Opinion essay B2 (280-320 words, topic) + 6 R/F requiring deep comprehension. goetheFormat:true, modules.lesen.',
        3000,
        '1/8: Lesen 1',
      ),
      b('lesenParts', 'Teil 2: Press article B2 (260-300 words) + 6 multiple choice a/b/c with plausible distractors.', 3000, '2/8: Lesen 2'),
      b(
        'lesenParts',
        'Teil 3: 6 ads/texts A-F (40-60 words each) + 5 person situations matching (one extra option 0). Teil 4: 5 opinions (35-50 words) + 5 Ja/Nein.',
        2800,
        '3/8: Lesen 3-4',
      ),
      b('lesenParts', 'Teil 5: Official text/norm 150-180 words + 5 multiple choice.', 2600, '4/8: Lesen 5'),
      b(
        'horenParts',
        'horenParts must be an ARRAY with exactly 2 objects. Item 1 (teil:1): plays:2, segments: 2 objects each with label, transcript (150-200 words B2), questions: 2 multiple-choice each. Item 2 (teil:2): plays:2, transcript (200-250 words), questions: 3 type:"multiple" A/B/C. Structure: { "horenParts": [{ "teil":1, "segments":[...] }, { "teil":2, "transcript":"...", "questions":[...] }] }',
        2800,
        '5/8: Hoeren 1-2',
      ),
      b(
        'horenParts',
        'horenParts must be an ARRAY with exactly 2 objects. Item 1 (teil:3): plays:2, transcript (180-220 words conversation), questions: 4 type:"richtig_falsch". Item 2 (teil:4): plays:2, context with 3 speakers, segments OR transcript with speaker labels, questions: 4 attribution multiple-choice. Structure: { "horenParts": [{ "teil":3, "transcript":"...", "questions":[...] }, { "teil":4, "segments":[...] OR "transcript":"...", "questions":[...] }] }',
        2600,
        '6/8: Hoeren 3-4',
      ),
      b(
        'schreibenParts',
        'Aufgabe 1: Semi-formal email 140-160 words, 3 content points. Aufgabe 2: Er�rterung 190-210 words pro/contra + own position. modelAnswer both.',
        2000,
        '7/8: Schreiben',
      ),
      b(
        'sprechenParts',
        'Teil 1: Complex joint planning (4 negotiation points). Teil 2: Presentation with thesis (intro, arguments, counter, position, conclusion). Teil 3: Critical discussion, 4 exchanges.',
        1800,
        '8/8: Sprechen',
      ),
    ];
  }

  function goetheC2(topic) {
    const b = (key, detail, maxTokens, label) =>
      g(key, detail, maxTokens, label, goetheBase('C2', topic, key, detail, ' official.certificate:"Goethe-Zertifikat C2".'));
    return [
      b(
        'lesenParts',
        'Teil 1-2: Dense academic/literary C2 texts 350-400 words + inference and attitude questions. goetheFormat:true.',
        3400,
        '1/8: Lesen 1-2',
      ),
      b('lesenParts', 'Teil 3-4: Specialized register texts + person_match / r_f_n items.', 3200, '2/8: Lesen 3-4'),
      b('lesenParts', 'Teil 5: Stylistic and lexical precision in context.', 3000, '3/8: Lesen 5'),
      b('lesenParts', 'Teil 6: Complex argumentative essay + subtle comprehension.', 2800, '4/8: Lesen 6'),
      b(
        'horenParts',
        'horenParts ARRAY 2 items. Teil 1-2: academic debate segments, transcript 220+ words C2, r_f_n and multiple-choice.',
        3000,
        '5/8: Hoeren 1-2',
      ),
      b(
        'horenParts',
        'horenParts ARRAY 2 items. Teil 3-4: lecture + panel discussion, noteFields and multiple-choice.',
        2800,
        '6/8: Hoeren 3-4',
      ),
      b('schreibenParts', 'Aufgabe 1: Argumentative essay 250 words. Aufgabe 2: Summary/reformulation 80 words. modelAnswer.', 2200, '7/8: Schreiben'),
      b('sprechenParts', 'Academic presentation + critical discussion with counter-arguments. modelAnswer.', 2000, '8/8: Sprechen'),
    ];
  }

  function goetheC1(topic) {
    const b = (key, detail, maxTokens, label) =>
      g(key, detail, maxTokens, label, goetheBase('C1', topic, key, detail, ' official.certificate:"Goethe-Zertifikat C1".'));
    return [
      b(
        'lesenParts',
        'Teil 1-2: Academic/literary texts 300-350 words each + deep comprehension questions. goetheFormat:true, modules.lesen.',
        3200,
        '1/8: Lesen 1-2',
      ),
      b('lesenParts', 'Teil 3-4: Specialized vocabulary texts + matching and multiple choice.', 3000, '2/8: Lesen 3-4'),
      b('lesenParts', 'Teil 5: Sprachmittel � choose correct form in context (grammar/vocab in text).', 2800, '3/8: Lesen 5'),
      b('lesenParts', 'Teil 6: Complex argumentation text + inference questions.', 2600, '4/8: Lesen 6'),
      b(
        'horenParts',
        'horenParts must be an ARRAY with exactly 2 objects. Item 1 (teil:1): plays:2, segments: 2 conference/debate excerpts each with label, transcript (200+ words C1), questions: 2-3 multiple-choice. Item 2 (teil:2): plays:2, transcript (200+ words), questions: 3-4 multiple-choice or richtig_falsch. Structure: { "horenParts": [{ "teil":1, "segments":[...] }, { "teil":2, "transcript":"...", "questions":[...] }] }',
        2800,
        '5/8: Hoeren 1-2',
      ),
      b(
        'horenParts',
        'horenParts must be an ARRAY with exactly 2 objects. Item 1 (teil:3): plays:2, transcript (academic lecture 200+ words), questions: 4 multiple-choice. Item 2 (teil:4): plays:2, transcript (200+ words), notesTitle, noteFields: 5 objects {id, label, answer}. Structure: { "horenParts": [{ "teil":3, "transcript":"...", "questions":[...] }, { "teil":4, "transcript":"...", "notesTitle":"...", "noteFields":[...] }] }',
        2600,
        '6/8: Hoeren 3-4',
      ),
      b('schreibenParts', 'Aufgabe 1: Opinion article 200 words. Aufgabe 2: Formal letter 80 words. modelAnswer both.', 2000, '7/8: Schreiben'),
      b('sprechenParts', 'Structured academic debate + argumentative monologue with refutation. modelAnswer.', 1800, '8/8: Sprechen'),
    ];
  }

  function cambridgeA1(topic) {
    const c = (key, detail, maxTokens, label) =>
      g(key, detail, maxTokens, label, camBase('A1', 'A1 Key (KET)', topic, key, detail));
    return [
      c(
        'readingParts',
        'Part 1: 5 very short texts (notices, SMS, 10-20 words, topic) + A/B/C each. Part 2: 3 texts (30-50 words) + 3 multiple choice.',
        2000,
        '1/4: Reading',
      ),
      c(
        'listeningParts',
        'listeningParts must be an ARRAY with exactly 2 objects. Item 1 (part:1): plays:2, segments: 5 objects each with label, transcript (25-40 words), questions: [{id,type:"multiple",question,options:["A)...","B)...","C)..."],correct}]. Item 2 (part:2): plays:2, transcript (60-80 words monologue), noteFields: 5 objects {id, label, answer} OR questions with short answers. Structure: { "listeningParts": [{ "part":1, "segments":[...] }, { "part":2, "transcript":"...", "noteFields":[...] }] }',
        2000,
        '2/4: Listening',
      ),
      c(
        'writingParts',
        'Part 1: Complete 5 sentences about topic (transform from given sentence). Part 2: Note/card 25-35 words, 3 content points. modelAnswer.',
        1500,
        '3/4: Writing',
      ),
      c(
        'speakingParts',
        'Part 1: 5 personal questions (A1, topic). Part 2: 5 questions on topic with keyword prompts. modelAnswer 1-2 sentences each.',
        1000,
        '4/4: Speaking',
      ),
    ];
  }

  function cambridgeA2(topic) {
    const c = (key, detail, maxTokens, label) =>
      g(key, detail, maxTokens, label, camBase('A2', 'A2 Key for Schools', topic, key, detail));
    return [
      c(
        'readingParts',
        'Part 1: 5 texts (40-70 words, simple past/present). Part 2: Matching. official.certificate:"A2 Key for Schools".',
        2200,
        '1/5: Reading 1-2',
      ),
      c('readingParts', 'Part 3: Continuous text 100-130 words + 5 multiple choice A/B/C.', 2000, '2/5: Reading 3'),
      c(
        'listeningParts',
        'listeningParts must be an ARRAY with exactly 3 objects. Part 1: segments (5 short conversations 40-60 words) each with question A/B/C. Part 2: transcript (monologue 80-100 words) + questions A/B/C. Part 3: transcript + noteFields (form fields to complete). Structure: { "listeningParts": [{ "part":1, "segments":[...] }, { "part":2, "transcript":"...", "questions":[...] }, { "part":3, "transcript":"...", "noteFields":[...] }] }',
        2400,
        '3/5: Listening',
      ),
      c('writingParts', 'Email reply 35-45 words, 3 content points, topic. modelAnswer.', 1500, '4/5: Writing'),
      c('speakingParts', 'Part 1 personal + Part 2 collaborative task A2. modelAnswer.', 1200, '5/5: Speaking'),
    ];
  }

  function cambridgeB1(topic) {
    const c = (key, detail, maxTokens, label) =>
      g(key, detail, maxTokens, label, camBase('B1', 'B1 Preliminary (PET)', topic, key, detail));
    return [
      c(
        'readingParts',
        'Part 1: Five short texts with multiple choice. Part 2: Matching 5 people to 8 options A-H. modules.lesen.',
        3200,
        '1/7: Reading 1-2',
      ),
      c('readingParts', 'Part 3: Long text gap-fill. Part 4: Multiple choice on text. readingParts array length 2.', 3000, '2/7: Reading 3-4'),
      c('readingParts', 'Part 5-6: Sentence completion and word formation if applicable.', 2600, '3/7: Reading 5-6'),
      c(
        'listeningParts',
        'listeningParts must be an ARRAY with exactly 2 objects. Item 1 (part:1): plays:2, segments: 7 short extracts each with label, transcript (30-50 words), questions: [{id,type:"multiple",options A/B/C}]. Item 2 (part:2): plays:2, transcript (100+ words), noteFields: 6 sentence-completion gaps {id, label, answer}. Structure: { "listeningParts": [{ "part":1, "segments":[...] }, { "part":2, "transcript":"...", "noteFields":[...] }] }',
        2800,
        '4/7: Listening 1-2',
      ),
      c(
        'listeningParts',
        'listeningParts must be an ARRAY with exactly 2 objects. Item 1 (part:3): plays:2, segments: 5 speaker extracts for matching. Item 2 (part:4): plays:2, transcript (interview 150+ words), questions: 6 type:"multiple" A/B/C. Structure: { "listeningParts": [{ "part":3, "segments":[...] }, { "part":4, "transcript":"...", "questions":[...] }] }',
        2800,
        '5/7: Listening 3-4',
      ),
      c('writingParts', 'Part 1: Email ~100 words. Part 2: Article or story ~100 words. modelAnswer both.', 2200, '6/7: Writing'),
      c('speakingParts', 'Part 1 interview, Part 2 photo description, Part 3 discussion. modelAnswer.', 2000, '7/7: Speaking'),
    ];
  }

  function cambridgeB2(topic) {
    const c = (key, detail, maxTokens, label) =>
      g(key, detail, maxTokens, label, camBase('B2', 'B2 First (FCE)', topic, key, detail));
    return [
      c('readingParts', 'Part 1: Multiple choice cloze � text 150-180 words, 8 gaps, 4 options A-D each (lexical/collocation).', 3000, '1/8: Reading 1'),
      c('readingParts', 'Part 2: Open cloze � text 150-180 words, 8 gaps, one grammatical answer each.', 3000, '2/8: Reading 2'),
      c(
        'readingParts',
        'Part 3: Word formation � 8 gaps with base words. Part 4: Key word transformation � 6 sentence pairs with model answers.',
        3200,
        '3/8: Reading 3-4',
      ),
      c(
        'readingParts',
        'Part 5: Long text 450-500 words + 6 multiple choice A-D deep comprehension. Part 6: Gapped text, 6 paragraphs removed, 7 options A-G.',
        3200,
        '4/8: Reading 5-6',
      ),
      c(
        'listeningParts',
        'listeningParts must be an ARRAY with exactly 2 objects. Item 1 (part:1): plays:2, segments: 8 extracts each with label, transcript (50-70 words), questions: 2 multiple-choice A/B/C each. Item 2 (part:2): plays:2, transcript (250-300 words), noteFields: 10 gap-fill {id, label, answer}. Structure: { "listeningParts": [{ "part":1, "segments":[...] }, { "part":2, "transcript":"...", "noteFields":[...] }] }',
        3000,
        '5/8: Listening 1-2',
      ),
      c(
        'listeningParts',
        'listeningParts must be an ARRAY with exactly 2 objects. Item 1 (part:3): plays:2, segments: 5 speaker extracts for matching A-F. Item 2 (part:4): plays:2, transcript (interview 300-350 words), questions: 7 type:"multiple" A/B/C. Structure: { "listeningParts": [{ "part":3, "segments":[...] }, { "part":4, "transcript":"...", "questions":[...] }] }',
        3000,
        '6/8: Listening 3-4',
      ),
      c('writingParts', 'Part 1: Essay 140-190 words with notes. Part 2: Article/formal letter/review choice. modelAnswer each.', 2500, '7/8: Writing'),
      c(
        'speakingParts',
        'Part 1: 6 interview questions. Part 2: Compare 2 photos. Part 3: Collaborative task card. Part 4: Extension debate questions. modelAnswer.',
        2000,
        '8/8: Speaking',
      ),
    ];
  }

  function cambridgeC1(topic) {
    const c = (key, detail, maxTokens, label) =>
      g(key, detail, maxTokens, label, camBase('C1', 'C1 Advanced (CAE)', topic, key, detail));
    return [
      c('readingParts', 'Part 1: Multiple choice cloze with advanced collocations. Text 200+ words.', 3200, '1/8: Reading 1'),
      c('readingParts', 'Part 2: Open cloze complex structures.', 3000, '2/8: Reading 2'),
      c('readingParts', 'Part 3: Word formation negative prefixes. Part 4: Cross-text multiple matching (4 texts, 10 questions).', 3200, '3/8: Reading 3-4'),
      c('readingParts', 'Part 5-6: Long texts 500-600 words, academic vocabulary, deep inference.', 3200, '4/8: Reading 5-6'),
      c(
        'listeningParts',
        'listeningParts must be an ARRAY with exactly 2 objects. Item 1 (part:1): plays:2, segments: 6 extended extracts each with transcript (60-80 words) and questions A/B/C. Item 2 (part:2): plays:2, transcript (monologue 200+ words CAE), questions: 6 multiple-choice. Structure: { "listeningParts": [{ "part":1, "segments":[...] }, { "part":2, "transcript":"...", "questions":[...] }] }',
        3000,
        '5/8: Listening 1-2',
      ),
      c(
        'listeningParts',
        'listeningParts must be an ARRAY with exactly 2 objects. Item 1 (part:3): plays:2, segments: 5 speaker extracts for matching. Item 2 (part:4): plays:2, transcript (debate 250+ words), questions: 8 multiple-choice. Structure: { "listeningParts": [{ "part":3, "segments":[...] }, { "part":4, "transcript":"...", "questions":[...] }] }',
        3000,
        '6/8: Listening 3-4',
      ),
      c('writingParts', 'Essay 220-260 words + formal proposal/report 220-260 words. modelAnswer.', 2500, '7/8: Writing'),
      c('speakingParts', 'Part 2 compare 3 photos. Part 3 abstract collaborative decision. modelAnswer.', 2000, '8/8: Speaking'),
    ];
  }

  function cambridgeC2(topic) {
    const c = (key, detail, maxTokens, label) =>
      g(key, detail, maxTokens, label, camBase('C2', 'C2 Proficiency (CPE)', topic, key, detail));
    return [
      c('readingParts', 'Advanced open cloze + key word transformation (subjunctive/inversion). Literary/academic texts 600+ words.', 3200, '1/6: Reading 1-2'),
      c('readingParts', 'Gapped literary text + complex comprehension.', 3200, '2/6: Reading 3-4'),
      c(
        'listeningParts',
        'listeningParts must be an ARRAY with exactly 2 objects. Item 1 (part:1): plays:2, segments: radio discussion with 3+ speakers, each segment with transcript and questions. Item 2 (part:2): plays:2, transcript (academic lecture 250+ words), questions: 6 multiple-choice. Structure: { "listeningParts": [{ "part":1, "segments":[...] }, { "part":2, "transcript":"...", "questions":[...] }] }',
        3000,
        '3/6: Listening 1-2',
      ),
      c(
        'listeningParts',
        'listeningParts must be an ARRAY with exactly 2 objects. Item 1 (part:3): plays:2, transcript (extended text 300+ words CPE), questions: 6 inference multiple-choice. Item 2 (part:4): plays:2, transcript + noteFields OR complex questions. Structure: { "listeningParts": [{ "part":3, "transcript":"...", "questions":[...] }, { "part":4, "transcript":"...", "noteFields":[...] }] }',
        2800,
        '4/6: Listening 3-4',
      ),
      c('writingParts', 'Academic essay 280-320 words + quality newspaper article/review. modelAnswer.', 2800, '5/6: Writing'),
      c('speakingParts', 'Abstract discussion card + argumentative monologue + examiner debate. modelAnswer.', 2200, '6/6: Speaking'),
    ];
  }

  function genericChunks(topic, subject, level) {
    const lang = subject === 'de' ? 'German' : 'English';
    const anti = subject === 'de' ? ANTI_DE : ANTI_EN;
    const global = subject === 'de' ? GLOBAL_DE : GLOBAL_EN;
    const isDE = subject === 'de';
    const mk = (key, detail, maxTokens, label) => ({
      expectKey: key,
      maxTokens,
      label,
      prompt: `${anti}\n${level} ${lang} exam chunk. Topic:"${topic}". Key:${key}. ${detail}\n${global}\n${JR}`,
    });
    return [
      mk(isDE ? 'lesenParts' : 'readingParts', 'Full reading module with authentic texts and verifiable questions.', 2800, '1/4: reading'),
      mk(
        isDE ? 'horenParts' : 'listeningParts',
        isDE
          ? 'horenParts ARRAY: use segments (label, transcript, questions) OR transcript+questions OR transcript+noteFields. One object per Teil.'
          : 'listeningParts ARRAY: use segments (label, transcript, questions) OR transcript+questions OR transcript+noteFields. One object per part.',
        2600,
        '2/4: listening',
      ),
      mk(isDE ? 'schreibenParts' : 'writingParts', 'Writing task(s) with modelAnswer and criteria.', 1800, '3/4: writing'),
      mk(isDE ? 'sprechenParts' : 'speakingParts', 'Speaking parts with situation and points.', 1200, '4/4: speaking'),
    ];
  }

  function chunksFor(subject, level, topic) {
    if (subject === 'de' && level === 'A1') return goetheA1(topic);
    if (subject === 'de' && level === 'A2') return goetheA2(topic);
    if (subject === 'de' && level === 'B1') return goetheB1(topic);
    if (subject === 'de' && level === 'B2') return goetheB2(topic);
    if (subject === 'de' && level === 'C1') return goetheC1(topic);
    if (subject === 'de' && level === 'C2') return goetheC2(topic);
    if (subject === 'en' && level === 'A1') return cambridgeA1(topic);
    if (subject === 'en' && level === 'A2') return cambridgeA2(topic);
    if (subject === 'en' && level === 'B1') return cambridgeB1(topic);
    if (subject === 'en' && level === 'B2') return cambridgeB2(topic);
    if (subject === 'en' && level === 'C1') return cambridgeC1(topic);
    if (subject === 'en' && level === 'C2') return cambridgeC2(topic);
    return genericChunks(topic, subject, level);
  }

  return { chunksFor };
})();
